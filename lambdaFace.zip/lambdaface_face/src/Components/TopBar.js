import React from 'react';
import '../Assets/LambdaLogo.svg';

export default () => {
  return (
    <div>
      <img src="../Assets/LamdaLogo.svg" alt="logo"/>
    </div>
  )
}