import React from 'react';

const Callback = () => {
  return <h5>Loading...</h5>
};

export default Callback;
